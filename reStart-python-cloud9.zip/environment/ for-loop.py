print("Count to 10!")
